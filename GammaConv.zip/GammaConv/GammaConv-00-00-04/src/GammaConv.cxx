// **********************************************************************
// *                            GammaConv.cxx                           *
// **********************************************************************
// * Version: 3.00                                                      *
// * Date: 25 July, 2016	                                              *
// * Author:                                                            *
// * Modified:                                                          *
// * Comment:                                                           *
// * Description: Correct Bfieldz, DeltaZ                               *
// **********************************************************************

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

#include "GammaConv/GammaConv.h"
#include "VertexFit/BField.h"
#include <iostream>
#include <vector>

using namespace std;
typedef std::vector<double> Vdouble;

const double alpha = 0.00299792458;
const double emass = 0.000511;
const double PI = 3.1415926535897932384626;

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

GammaConv::GammaConv(HepVector helixp, HepVector helixe, HepPoint3D ip) {
    PhiThetaXi(helixp, helixe);
    Vertex(helixp, helixe);
    Rxy(ip);
    DGamma(helixp, helixe, ip);
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

GammaConv::~GammaConv() {}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

double GammaConv::bfieldz(HepVector helix) {
    double bz = VertexFitBField::instance()->getBFieldZ(x3(helix));
    return bz;
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

int GammaConv::charge(HepVector helix) {
    int q = helix[2] > 0 ? +1 : -1;
    return q;
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

double GammaConv::radius(HepVector helix) {
    double bz = bfieldz(helix);
    int q = charge(helix);
    double a = alpha * bz * q;
    double pxy = q / helix[2];
    double r = fabs(pxy / a);
    return r;
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

HepPoint3D GammaConv::x3(HepVector helix) {
    return HepPoint3D(helix[0] * cos(helix[1]), helix[0] * sin(helix[1]),
                      helix[3]);
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

Hep3Vector GammaConv::p3(HepVector helix) {
    double pxy = 1. / fabs(helix[2]);
    return Hep3Vector(0 - pxy * sin(helix[1]), pxy * cos(helix[1]),
                      pxy * helix[4]);
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

double GammaConv::drho(HepVector helix) {
    double d = fabs(helix[0]);
    return d;
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

double GammaConv::phi(HepVector helix) {
    HepPoint3D d = x3(helix);
    double dr = drho(helix);
    double Phi0 = d.y() >= 0 ? acos(d.x() / dr) : (2 * PI - acos(d.x() / dr));
    return Phi0;
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

double GammaConv::theta(HepVector helix) {
    double Theta = atan(helix[4]);
    return Theta;
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

double GammaConv::angle(HepPoint3D A, HepPoint3D B) {
    double la = sqrt(A.x() * A.x() + A.y() * A.y());
    double lb = sqrt(B.x() * B.x() + B.y() * B.y());
    double a_b = A.x() * B.x() + A.y() * B.y();
    double cos_ab = (la > 0 && lb > 0) ? a_b / (la * lb) : -99;
    double ang_ab = (cos_ab >= -1) ? acos(cos_ab) : -99;
    return ang_ab;
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

double GammaConv::getZ(HepVector helix, HepPoint3D point) {
    HepPoint3D begin = x3(helix);
    Hep3Vector p = p3(helix);
    HepPoint3D vec = point - begin;
    double r = radius(helix);
    double theta = 2 * angle(vec, p);
    double z = helix[3] + helix[4] * theta * r;
    return z;
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

HepPoint3D GammaConv::center(HepVector helix) {
    int q = charge(helix);
    double rad = radius(helix);
    double x = (helix[0] - q * rad) * cos(helix[1]);
    double y = (helix[0] - q * rad) * sin(helix[1]);
    double z = 0.0;
    return HepPoint3D(x, y, z);
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

void GammaConv::Vertex(HepVector helixp, HepVector helixe) {

    double rp = radius(helixp);
    double re = radius(helixe);
    m_rp = rp;
    m_re = re;

    double xp = center(helixp).x();
    double yp = center(helixp).y();
    double xe = center(helixe).x();
    double ye = center(helixe).y();

    double lep = sqrt((xp - xe) * (xp - xe) + (yp - ye) * (yp - ye));
    m_lep = lep;
    m_dxy = lep - rp - re;

    double x_a = xp + (xe - xp) * rp / lep;
    double y_a = yp + (ye - yp) * rp / lep;
    double x_b = xe + (xp - xe) * re / lep;
    double y_b = ye + (yp - ye) * re / lep;
    HepPoint3D A(x_a, y_a, 0);
    HepPoint3D B(x_b, y_b, 0);
    double z_a = getZ(helixp, A);
    double z_b = getZ(helixe, B);

    // calculate intersections
    double x = xp - xe;
    double y = yp - ye;
    double p = xp * xp + yp * yp - rp * rp;
    double e = xe * xe + ye * ye - re * re;
    double r = p - e;
    double a = 1 + y * y / (x * x);
    double b = 2 * (xe * yp - xp * ye) / x - r * y / (x * x);
    double c = r * r / (4 * x * x) + (xp * e - xe * p) / x;
    double d = b * b - 4 * a * c;
    m_deltaeq = d;

    if (d >= 0) {
        double y_m = (-b + sqrt(d)) / (2 * a);
        double x_m = r / (2 * x) - (y / x) * y_m;
        double y_n = (-b - sqrt(d)) / (2 * a);
        double x_n = r / (2 * x) - (y / x) * y_n;
        HepPoint3D M(x_m, y_m, 0);
        HepPoint3D N(x_n, y_n, 0);
        double zp_m = getZ(helixp, M);
        double ze_m = getZ(helixe, M);
        double dz_m = fabs(zp_m - ze_m);
        double zp_n = getZ(helixp, N);
        double ze_n = getZ(helixe, N);
        double dz_n = fabs(zp_n - ze_n);
        if (dz_m <= dz_n) {
            m_coordip1.setX(x_m);
            m_coordip1.setY(y_m);
            m_coordip1.setZ(zp_m);
            m_coordie1.setX(x_m);
            m_coordie1.setY(y_m);
            m_coordie1.setZ(ze_m);
            m_dz1 = dz_m;
        } else {
            m_coordip1.setX(x_n);
            m_coordip1.setY(y_n);
            m_coordip1.setZ(zp_n);
            m_coordie1.setX(x_n);
            m_coordie1.setY(y_n);
            m_coordie1.setZ(ze_n);
            m_dz1 = dz_n;
        }
    } else {
        m_coordip1.setX(x_a);
        m_coordip1.setY(y_a);
        m_coordip1.setZ(z_a);
        m_coordie1.setX(x_b);
        m_coordie1.setY(y_b);
        m_coordie1.setZ(z_b);
        m_dz1 = fabs(z_a - z_b);
    }

    m_coordip2.setX(x_a);
    m_coordip2.setY(y_a);
    m_coordip2.setZ(z_a);
    m_coordie2.setX(x_b);
    m_coordie2.setY(y_b);
    m_coordie2.setZ(z_b);
    m_dz2 = fabs(z_a - z_b);
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

void GammaConv::Rxy(HepPoint3D ip) {
    HepPoint3D OA, OB, OM;
    OA = m_coordip1 - ip;
    OB = m_coordie1 - ip;
    OM = (OA + OB) * 0.5;
    m_rx1 = OM.x();
    m_ry1 = OM.y();
    m_rz1 = OM.z();
    m_rxy1 = sqrt(OM.x() * OM.x() + OM.y() * OM.y());

    OA = m_coordip2 - ip;
    OB = m_coordie2 - ip;
    OM = (OA + OB) * 0.5;
    m_rx2 = OM.x();
    m_ry2 = OM.y();
    m_rz2 = OM.z();
    m_rxy2 = sqrt(OM.x() * OM.x() + OM.y() * OM.y());

    if (m_xiep >= 10) {
        m_rx = m_rx1;
        m_ry = m_ry1;
        m_rz = m_rz1;
        m_rxy = m_rxy1;
    } else {
        m_rx = m_rx2;
        m_ry = m_ry2;
        m_rz = m_rz2;
        m_rxy = m_rxy2;
    }
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

void GammaConv::getCoordi1(HepPoint3D &coordip1, HepPoint3D &coordie1) {
    coordip1 = m_coordip1;
    coordie1 = m_coordie1;
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

void GammaConv::getCoordi2(HepPoint3D &coordip2, HepPoint3D &coordie2) {
    coordip2 = m_coordip2;
    coordie2 = m_coordie2;
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

void GammaConv::DGamma(HepVector helixp, HepVector helixe, HepPoint3D ip) {
    double Ep = sqrt(emass * emass + p3(helixp).mag2());
    double Ee = sqrt(emass * emass + p3(helixe).mag2());
    HepLorentzVector p4p(p3(helixp), Ep);
    HepLorentzVector p4e(p3(helixe), Ee);
    HepLorentzVector p4gamma(p4p + p4e);
    double p = p4gamma.vect().mag();
//    double mf1 = (m_rx1 - ip.x()) * p4gamma.px() / p +
//                 (m_ry1 - ip.y()) * p4gamma.py() / p +
//                 (m_rz1 - ip.z()) * p4gamma.pz() / p;
//    double om1 = sqrt((ip.x() - m_rx1) * (ip.x() - m_rx1) +
//                      (ip.y() - m_ry1) * (ip.y() - m_ry1) +
//                      (ip.z() - m_rz1) * (ip.z() - m_rz1));
//    double mf2 = (m_rx2 - ip.x()) * p4gamma.px() / p +
//                 (m_ry2 - ip.y()) * p4gamma.py() / p +
//                 (m_rz2 - ip.z()) * p4gamma.pz() / p;
//    double om2 = sqrt((ip.x() - m_rx2) * (ip.x() - m_rx2) +
//                      (ip.y() - m_ry2) * (ip.y() - m_ry2) +
//                      (ip.z() - m_rz2) * (ip.z() - m_rz2));
    double mf1 = m_rx1 * p4gamma.px() / p +
                 m_ry1 * p4gamma.py() / p +
                 m_rz1 * p4gamma.pz() / p;
    double om1 = sqrt(m_rx1 * m_rx1 +
                      m_ry1 * m_ry1 +
                      m_rz1 * m_rz1);
    double mf2 = m_rx2 * p4gamma.px() / p +
                 m_ry2 * p4gamma.py() / p +
                 m_rz2 * p4gamma.pz() / p;
    double om2 = sqrt(m_rx2 * m_rx2 +
                      m_ry2 * m_ry2 +
                      m_rz2 * m_rz2);
    m_dgamma1 = sqrt(om1 * om1 - mf1 * mf1);
    m_dgamma2 = sqrt(om2 * om2 - mf2 * mf2);
    if (m_xiep >= 10) {
        m_dgamma = m_dgamma1;
    } else {
        m_dgamma = m_dgamma2;
    }

    Hep3Vector dir1(m_rx1, m_ry1, m_rz1);
    Hep3Vector dir2(m_rx2, m_ry2, m_rz2);
    if (m_xiep >= 10) {
        m_thetaep = dir1.angle(p4gamma.vect());
    } else {
        m_thetaep = dir2.angle(p4gamma.vect());
    }
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

void GammaConv::PhiThetaXi(HepVector helixp, HepVector helixe) {
    double phip = phi(helixp);
    double phie = phi(helixe);
    double dphi = phip - phie;
    m_phip = phip;
    m_phie = phie;
    m_dphi = dphi;
    double thetap = theta(helixp);
    double thetae = theta(helixe);
    double dtheta = thetap - thetae;
    m_thetap = thetap;
    m_thetae = thetae;
    m_dtheta = dtheta;
    double xiep =
        acos(p3(helixp) * p3(helixe) / p3(helixp).mag() / p3(helixe).mag()) *
        180 / PI;
    double psipair = asin(dtheta / xiep);
    m_xiep = xiep;
    m_psipair = psipair;
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......
