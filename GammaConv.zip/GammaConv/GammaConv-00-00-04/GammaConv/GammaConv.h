#ifndef Physics_Analysis_GammaConv_H
#define Physics_Analysis_GammaConv_H

#include "VertexFit/HTrackParameter.h"
#include "VertexFit/WTrackParameter.h"
#include "CLHEP/Matrix/Vector.h"
using CLHEP::HepVector;
#include "CLHEP/Vector/LorentzVector.h"
using CLHEP::HepLorentzVector;

#ifndef CLHEP_THREEVECTOR_H
#include "CLHEP/Vector/ThreeVector.h"
using CLHEP::Hep3Vector;
#endif

#ifndef CLHEP_POINT3D_H
#include "CLHEP/Geometry/Point3D.h"
#ifndef ENABLE_BACKWARDS_COMPATIBILITY
   typedef HepGeom::Point3D<double> HepPoint3D;
#endif
#endif

class GammaConv{

public:
  GammaConv(HepVector helixp, HepVector helixe, HepPoint3D ip);
  ~GammaConv();

  double getRp() {return m_rp;}
  double getRe() {return m_re;}
  double getLep() {return m_lep;}
  double getDxy() {return m_dxy;}
  double getDz1() {return m_dz1;}
  double getDz2() {return m_dz2;}
  double getRx() {return m_rx;}
  double getRy() {return m_ry;}
  double getRz() {return m_rz;}
  double getRxy(){return m_rxy;}
  double getRx1() {return m_rx1;}
  double getRy1() {return m_ry1;}
  double getRz1() {return m_rz1;}
  double getRxy1(){return m_rxy1;}
  double getRx2() {return m_rx2;}
  double getRy2() {return m_ry2;}
  double getRz2() {return m_rz2;}
  double getRxy2() {return m_rxy2;}
  double getDGamma() {return m_dgamma;}
  double getDGamma1() {return m_dgamma1;}
  double getDGamma2() {return m_dgamma2;}
	double getPhip() {return m_phip;}
	double getPhie() {return m_phie;}
	double getDPhi() {return m_dphi;}
	double getThetap() {return m_thetap;}
	double getThetae() {return m_thetae;}
	double getDTheta() {return m_dtheta;}
	double getXiep() {return m_xiep;}
  double getPsipair() {return m_psipair;}
  double getDeltaeq() {return m_deltaeq;}
  double getThetaep() {return m_thetaep;}
  void getCoordi1(HepPoint3D &coordip1, HepPoint3D &coordie1);
  void getCoordi2(HepPoint3D &coordip2, HepPoint3D &coordie2);

private:
	int charge(HepVector helix);
	double bfieldz(HepVector helix);
	double radius(HepVector helix);
	double drho(HepVector helix);
	double phi(HepVector helix);
	double theta(HepVector helix);
	double angle(HepPoint3D A, HepPoint3D B);
	double getZ(HepVector helix, HepPoint3D point);
  HepPoint3D center(HepVector helix);
  HepPoint3D x3(HepVector helix);
  Hep3Vector p3(HepVector helix);
  void Vertex(HepVector helixp, HepVector helixe);
  void Rxy(HepPoint3D ip);
  void DGamma(HepVector helixp, HepVector helixe, HepPoint3D ip);
  void PhiThetaXi(HepVector helixp, HepVector helixe);

private:
  double m_rp;
	double m_re;
  double m_lep;
  double m_deltaeq;
  double m_dxy;
  double m_dz1;
	double m_dz2;
  double m_rx;
  double m_ry;
  double m_rz;
  double m_rxy;
  double m_rx1;
  double m_ry1;
  double m_rz1;
  double m_rxy1;
  double m_rx2;
  double m_ry2;
  double m_rz2;
  double m_rxy2;
  double m_dgamma;
  double m_dgamma1;
  double m_dgamma2;
  double m_phip;
  double m_phie;
  double m_dphi;
  double m_thetap;
  double m_thetae;
  double m_dtheta;
  double m_xiep;
  double m_psipair;
  double m_thetaep;
 
  HepPoint3D m_coordip1, m_coordie1;
  HepPoint3D m_coordip2, m_coordie2;

};
#endif
