# echo "cleanup GammaConv GammaConv-00-00-04 in /workfs2/bes/liziyang/workarea/7.0.9/Utilities"

if test "${CMTROOT}" = ""; then
  CMTROOT=/cvmfs/bes3.ihep.ac.cn/bes3sw/ExternalLib/SLC6/contrib/CMT/v1r25; export CMTROOT
fi
. ${CMTROOT}/mgr/setup.sh
cmtGammaConvtempfile=`${CMTROOT}/mgr/cmt -quiet build temporary_name`
if test ! $? = 0 ; then cmtGammaConvtempfile=/tmp/cmt.$$; fi
${CMTROOT}/mgr/cmt cleanup -sh -pack=GammaConv -version=GammaConv-00-00-04 -path=/workfs2/bes/liziyang/workarea/7.0.9/Utilities  $* >${cmtGammaConvtempfile}
if test $? != 0 ; then
  echo >&2 "${CMTROOT}/mgr/cmt cleanup -sh -pack=GammaConv -version=GammaConv-00-00-04 -path=/workfs2/bes/liziyang/workarea/7.0.9/Utilities  $* >${cmtGammaConvtempfile}"
  cmtcleanupstatus=2
  /bin/rm -f ${cmtGammaConvtempfile}
  unset cmtGammaConvtempfile
  return $cmtcleanupstatus
fi
cmtcleanupstatus=0
. ${cmtGammaConvtempfile}
if test $? != 0 ; then
  cmtcleanupstatus=2
fi
/bin/rm -f ${cmtGammaConvtempfile}
unset cmtGammaConvtempfile
return $cmtcleanupstatus

