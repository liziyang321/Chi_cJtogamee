# echo "cleanup McTruth McTruth-00-02-19 in /workfs2/bes/liziyang/workarea/7.0.9/Analysis"

if test "${CMTROOT}" = ""; then
  CMTROOT=/cvmfs/bes3.ihep.ac.cn/bes3sw/ExternalLib/SLC6/contrib/CMT/v1r25; export CMTROOT
fi
. ${CMTROOT}/mgr/setup.sh
cmtMcTruthtempfile=`${CMTROOT}/mgr/cmt -quiet build temporary_name`
if test ! $? = 0 ; then cmtMcTruthtempfile=/tmp/cmt.$$; fi
${CMTROOT}/mgr/cmt cleanup -sh -pack=McTruth -version=McTruth-00-02-19 -path=/workfs2/bes/liziyang/workarea/7.0.9/Analysis  $* >${cmtMcTruthtempfile}
if test $? != 0 ; then
  echo >&2 "${CMTROOT}/mgr/cmt cleanup -sh -pack=McTruth -version=McTruth-00-02-19 -path=/workfs2/bes/liziyang/workarea/7.0.9/Analysis  $* >${cmtMcTruthtempfile}"
  cmtcleanupstatus=2
  /bin/rm -f ${cmtMcTruthtempfile}
  unset cmtMcTruthtempfile
  return $cmtcleanupstatus
fi
cmtcleanupstatus=0
. ${cmtMcTruthtempfile}
if test $? != 0 ; then
  cmtcleanupstatus=2
fi
/bin/rm -f ${cmtMcTruthtempfile}
unset cmtMcTruthtempfile
return $cmtcleanupstatus

